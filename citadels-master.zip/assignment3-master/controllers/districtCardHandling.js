// This function calls for dc building
exports.initialiseDcPanel = function(req, res) {
    /*players = JSON.parse(req.query.playersData);
    index =[];
    data='';  
    for(var i=0;i< players.length;i++){
        if(players[i].name === req.query.userName){
            
           for( var j=0;j<players[i].dcsArray.length;j++){
               
            }  
        }         
    } */
    data ='';
     data  = JSON.stringify(data) 
    return res.send(data);
};
