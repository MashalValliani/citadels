// This function calls at after every turn in the game flow when player updates their hand - this will update the hand panel Dcs
exports.initialiseCcPanel = function(req, res) {
    /*players = JSON.parse(req.query.playersData);
    index =[];
    data='';  
    for(var i=0;i< players.length;i++){
        if(players[i].name === req.query.userName){
            
           for( var j=0;j<players[i].dcsArray.length;j++){
            
            }  
        }         
    } */
    data ='';
     data  = JSON.stringify(data) 
    return res.send(data);
};
